# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 18:26:22 2024

@author: admin
"""

import numpy as np
from ioh import get_problem, logger, ProblemClass
from s4024354_s3977226_ES import ES, ES2, create_problem
from typing import List
import matplotlib.pyplot as plt
from time import time
budget = 1000000
np.random.seed(42)


# Hyperparameters to tune, e.g.
hyperparameter_space = {
    "sigmas": [ 0.01, 0.1, 1],
    "mu_values": [16, 64, 4],
    "lambda_values": [128, 64, 256]}


def tune_hyperparameters() -> List:
    results = []  
    repetitions = 20
    batch_size = 1000
    t0 = time()
    for sigma in hyperparameter_space['sigmas']:
        for mu in hyperparameter_space['mu_values']:
            for lambda_ in hyperparameter_space['lambda_values']:
                print(f"Testing with sigma={sigma}, mu={mu}, lambda={lambda_}")
                
                score_mu_plus_lambda = 0
                score_mu_comma_lambda = 0
                avg_fitness_history_mu_plus_lambda = None
                avg_fitness_history_mu_comma_lambda = None
                t2 = time()
                for _ in range(repetitions):
                    # Create separate problem instances 
                    F23_plus_lambda, _logger = create_problem(fid=23)
                    F23_comma_lambda, _logger = create_problem(fid=23)

                    fitness_history_mu_plus_lambda = ES(
                        F23_plus_lambda, mu, lambda_, sigma, budget // repetitions, batch_size)
                    score_mu_plus_lambda += F23_plus_lambda.state.current_best.y # (mu+lambda)

                    fitness_history_mu_comma_lambda = ES2(
                        F23_comma_lambda, mu, lambda_, sigma, budget // repetitions, batch_size)
                    score_mu_comma_lambda += F23_comma_lambda.state.current_best.y # (mu,lambda)

                    if avg_fitness_history_mu_plus_lambda is None:
                        avg_fitness_history_mu_plus_lambda = np.array(fitness_history_mu_plus_lambda)
                    else:
                        avg_fitness_history_mu_plus_lambda += np.array(fitness_history_mu_plus_lambda)

                    if avg_fitness_history_mu_comma_lambda is None:
                        avg_fitness_history_mu_comma_lambda = np.array(fitness_history_mu_comma_lambda)
                    else:
                        avg_fitness_history_mu_comma_lambda += np.array(fitness_history_mu_comma_lambda)

                avg_score_mu_plus_lambda = score_mu_plus_lambda / repetitions
                avg_score_mu_comma_lambda = score_mu_comma_lambda / repetitions
                avg_fitness_history_mu_plus_lambda /= repetitions
                avg_fitness_history_mu_comma_lambda /= repetitions

                results.append((avg_score_mu_plus_lambda, (sigma, mu, lambda_, "mu+lambda"), avg_fitness_history_mu_plus_lambda))
                results.append((avg_score_mu_comma_lambda, (sigma, mu, lambda_, "mu,lambda"), avg_fitness_history_mu_comma_lambda))
                t3 = time()
                print(f"Running time For This Combination:{t3-t2}")
    # 按分数升序排序
    results.sort(key=lambda x: x[0])
    best_result = results[0]
    sigma, mu, lambda_, strategy = best_result[1]
    avg_score = best_result[0]
    t1 = time()
    print(f"Total Running time:{t1-t0}")
    return sigma, mu, lambda_, strategy, avg_score, results[:5]




if __name__ == "__main__":
    # 超参数调优，获取表现最好的 5 个参数组合
    sigma, mu, lambda_, strategy, avg_score, top_results = tune_hyperparameters()
    print(f"top_results:{top_results}")
    

    print("Top 5 Hyperparameter Combinations:")
    for rank, (score, params, _) in enumerate(top_results, start=1):
        sigma, mu, lambda_, strategy = params
        print(f"Rank {rank}: Strategy={strategy}, Sigma={sigma}, Mu={mu}, Lambda={lambda_}, Score={score}")
    
    best_fitness_history_length = len(top_results[0][2])
    plt.figure(figsize=(10, 6))
    for rank, (_, params, avg_score) in enumerate(top_results, start=1):
        sigma, mu, lambda_, strategy = params
        #print(f"fitness_history:{fitness_history}")
        log_fitness_history = np.log10(np.array(avg_score))
        #truncated_fitness_history = log_fitness_history[:best_fitness_history_length]
        plt.plot(range(len(log_fitness_history)), log_fitness_history, label=f"Rank {rank}: Strategy={strategy}, Sigma={sigma}, Mu={mu}, Lambda={lambda_}")
    ax = plt.gca()  
    original_ticks = ax.get_xticks()  
    scaled_ticks = original_ticks * 20  
    ax.set_xticklabels(scaled_ticks.astype(int))
    plt.xlabel("Evaluation Count",fontsize=16)
    plt.ylabel("Best log(f(x))",fontsize=16)
    plt.title("ES Performance with Top 5 Parameter and Strategy Combinations",fontsize=20)
    plt.legend()
    plt.show()
    
    plt.figure(figsize=(10, 6))
    for rank, (_, params, avg_score) in enumerate(top_results, start=1):
        sigma, mu, lambda_, strategy = params
        #print(f"fitness_history:{fitness_history}")
        log_fitness_history = np.log10(np.array(avg_score))
        #truncated_fitness_history = log_fitness_history[:best_fitness_history_length]
        plt.plot(range(len(avg_score)), avg_score, label=f"Rank {rank}: Strategy={strategy}, Sigma={sigma}, Mu={mu}, Lambda={lambda_}")
    ax = plt.gca()  
    original_ticks = ax.get_xticks()  
    scaled_ticks = original_ticks * 20  
    ax.set_xticklabels(scaled_ticks.astype(int))
    plt.xlabel("Evaluation Count",fontsize=16)
    plt.ylabel("Best log(f(x))",fontsize=16)
    plt.title("ES Performance with Top 5 Parameter and Strategy Combinations",fontsize=20)
    plt.legend()
    plt.savefig("plot_result.pdf", dpi=300, format="pdf") 
    plt.show()
    
    sigma = top_results[0][1][0]
    mu = top_results[0][1][1]
    lambda_ = top_results[0][1][2]
    strategy = top_results[0][1][3]
    best_score = top_results[0][0]
    print(top_results[0])
    print(f"Best Strategy:{strategy}")
    print(f"Best Sigma: {sigma}")
    print(f"Best Mu: {mu}")
    print(f"Best Lambda: {lambda_}")
    print(f"Best f(x) value: {best_score}")


