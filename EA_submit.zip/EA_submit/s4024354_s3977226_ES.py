import numpy as np
import optuna
from ioh import get_problem, logger, ProblemClass


def evaluate_in_batches(problem, population, batch_size=10):
    """Evaluate population fitness in batches."""
    fitness = []
    for i in range(0, len(population), batch_size):
        batch = population[i:i + batch_size]
        batch_fitness = [problem(ind) for ind in batch]
        fitness.extend(batch_fitness)
    return np.array(fitness)


def es_mu_plus_lambda(problem, mu, lambda_, sigma, max_evaluations, batch_size=10):
    """(μ+λ) ES."""
    dim = problem.meta_data.n_variables
    population = np.random.uniform(-5, 5, (mu, dim))
    fitness = evaluate_in_batches(problem, population, batch_size)

    while problem.state.evaluations < max_evaluations:
        # Generate offspring
        offspring = []
        for _ in range(lambda_):
            parents = population[np.random.choice(range(mu), size=2, replace=False)]
            child = np.mean(parents, axis=0) + np.random.normal(0, sigma, size=dim)
            offspring.append(child)
        offspring = np.array(offspring)
        offspring_fitness = evaluate_in_batches(problem, offspring, batch_size)

        # Combine population and offspring
        combined_population = np.vstack((population, offspring))
        combined_fitness = np.hstack((fitness, offspring_fitness))

        # Select top mu individuals
        indices = np.argsort(combined_fitness)
        population = combined_population[indices[:mu]]
        fitness = combined_fitness[indices[:mu]]

    return np.min(fitness)


def es_mu_comma_lambda(problem, mu, lambda_, sigma, max_evaluations, batch_size=10):
    """(μ,λ) ES."""
    dim = problem.meta_data.n_variables
    population = np.random.uniform(-5, 5, (mu, dim))

    while problem.state.evaluations < max_evaluations:
        # Generate offspring
        offspring = []
        for _ in range(lambda_):
            parents = population[np.random.choice(range(mu), size=2, replace=False)]
            child = np.mean(parents, axis=0) + np.random.normal(0, sigma, size=dim)
            offspring.append(child)
        offspring = np.array(offspring)

        # Evaluate offspring
        offspring_fitness = evaluate_in_batches(problem, offspring, batch_size)

        # Select top mu individuals from offspring
        indices = np.argsort(offspring_fitness)
        population = offspring[indices[:mu]]

    return np.min(offspring_fitness)


def create_problem(fid=23, dimension=10):
    """Create the BBOB problem."""
    problem = get_problem(fid, instance=1, dimension=dimension, problem_class=ProblemClass.BBOB)
    log_folder = "ioh_logs"
    l = logger.Analyzer(
        root=log_folder,
        folder_name="run",
        algorithm_name="Evolution Strategy",
        algorithm_info="Optimization of F23 using ES"
    )
    problem.attach_logger(l)
    return problem, l


def tune_hyperparameters(es_function):
    """Tune hyperparameters using Optuna."""
    max_total_evaluations = 100000  # Limit for total evaluations across all trials
    evaluation_counter = [0]  # Use a mutable object to track evaluations across trials

    def objective(trial):
        if evaluation_counter[0] >= max_total_evaluations:
            raise optuna.exceptions.TrialPruned()

        # Suggest hyperparameters
        mu = trial.suggest_int("mu", 4, 64)
        lambda_ = trial.suggest_int("lambda_", mu, 4 * mu)
        sigma = trial.suggest_float("sigma", 0.01, 1.0, log=True)

        # Create and reset problem
        problem, logger_ = create_problem(fid=23, dimension=10)
        problem.reset()

        # Run the selected ES function
        fitness = es_function(problem, mu, lambda_, sigma, max_evaluations=50000)
        logger_.close()

        evaluation_counter[0] += 50000
        return -fitness  # Minimize fitness

    print(f"Starting hyperparameter tuning for {es_function.__name__}...")
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=50)

    print(f"Best hyperparameters for {es_function.__name__}: {study.best_params}")
    return study.best_params


if __name__ == "__main__":
    # Tune hyperparameters for both ES variants
    np.random.seed(42)
    best_params_mu_plus_lambda = tune_hyperparameters(es_mu_plus_lambda)
    best_params_mu_comma_lambda = tune_hyperparameters(es_mu_comma_lambda)

    print("\nBest Hyperparameters for (μ+λ) ES:")
    print(best_params_mu_plus_lambda)

    print("\nBest Hyperparameters for (μ,λ) ES:")
    print(best_params_mu_comma_lambda)

    # Solve the problem using the best parameters for (μ+λ) ES
    problem_mu_plus_lambda, _logger = create_problem(fid=23, dimension=10)
    _logger_mu_plus_lambda = logger.Analyzer(store_positions=True, algorithm_name="(μ+λ) ES")
    problem_mu_plus_lambda.attach_logger(_logger_mu_plus_lambda)
    for run in range(20):
        print(f"(μ+λ) Run {run + 1}/20...")
        es_mu_plus_lambda(problem_mu_plus_lambda, **best_params_mu_plus_lambda, max_evaluations=50000)
        problem_mu_plus_lambda.reset()
    _logger_mu_plus_lambda.close()

    # Solve the problem using the best parameters for (μ,λ) ES
    problem_mu_comma_lambda, _logger = create_problem(fid=23, dimension=10)
    _logger_mu_comma_lambda = logger.Analyzer(store_positions=True, algorithm_name="(μ,λ) ES")
    problem_mu_comma_lambda.attach_logger(_logger_mu_comma_lambda)
    for run in range(20):
        print(f"(μ,λ) Run {run + 1}/20...")
        es_mu_comma_lambda(problem_mu_comma_lambda, **best_params_mu_comma_lambda, max_evaluations=50000)
        problem_mu_comma_lambda.reset()
    _logger_mu_comma_lambda.close()
